package question8;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 try
		  {
		   System.out.println("try block");
		  }
		  finally
		  {
		   System.out.println("finally block");
		  }

	}

}
