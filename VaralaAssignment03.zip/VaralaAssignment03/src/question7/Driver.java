package question7;

public class Driver {
	/*
	 * final Driver(){ System.out.println("Constructor"); }
	 */
		// TODO Auto-generated method stub
		public static final void main(String[] args) {
		    Driver obj1 = new Driver();
		}

	}