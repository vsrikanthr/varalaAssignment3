package covariantReturnType;

public class FirstClass {
	
	public Object a1()
	 { 
	   System.out.println("superclass"); 
	    return null; 
	  } 

}
