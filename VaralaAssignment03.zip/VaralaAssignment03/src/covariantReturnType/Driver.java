package covariantReturnType;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 
		     SecondClass x = new SecondClass(); 
		      x.a1(); 
		     FirstClass y = new SecondClass(); 
		      y.a1(); 
		   } 

	}


