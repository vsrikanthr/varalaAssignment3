package covariantReturnType;

public class SecondClass extends FirstClass {
	
	@Override 
	  public String a1()
	  { 
	     System.out.println("subclass"); 
	      return null; 
	  } 

}
