package overridePrivateStatic;

public class SuperClass {
	
	private void msg() {
	      System.out.println("Super Class");    
	   }
	static void greetings() {
		System.out.println("Hello");
	}

}
