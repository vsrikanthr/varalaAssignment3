package question10;

public class SuperClass {
	void method() {
	    System.out.println("Super");
	  }
	void msg() {
		System.out.println("hello");
	}

}
